package com.quiz.model;

public class QuizAttempt {

}
