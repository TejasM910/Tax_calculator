package TAX;

public class UserDetails {

	public static void UserDetails(String user,String pass) {}
}
