package TAX;

import java.util.Scanner;


public class Homepage {
	public static void main() {
	while(true) {
		System.out.println("Home Page");
		System.out.println("Property Tax");
		System.out.println("Vehicle Tax");
		System.out.println("Total ");
		System.out.println("Exit");
		Scanner sc = new Scanner(System.in);
		int options=sc.nextInt();
		 if (options == 1) {
	System.out.println("property Tax gng");
	Operationclass.property();
	}
		 else if (options == 2) {
			 System.out.println("Vehicle Tax gng");
			 Operationclass.vehicle();
	}
		 else if (options == 3) {
			 System.out.println("total gng");
			 Operationclass.total();
		 } 
		 else if (options == 4)
		 {
	         System.out.println("Exited from the application");
	         break; 
	     } 
		 else {
	         System.out.println("Invalid choice. Please try again.");
	     }}
}}
