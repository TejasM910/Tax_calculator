package TAX;

public class exitbaseclass {
	private int srno;
	private String particular;
	private int quantity;
	private double tax;
	public int getSrno() {
		return srno;
	}
	public void setSrno(int srno) {
		this.srno = srno;
	}
	public String getParticular() {
		return particular;
	}
	public void setParticular(String particular) {
		this.particular = particular;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getTax() {
		return tax;
	}
	public void setTax(double tax) {
		this.tax = tax;
	}
	public exitbaseclass(int srno, String particular, int quantity, double tax) {
		super();
		this.srno = srno;
		this.particular = particular;
		this.quantity = quantity;
		this.tax = tax;
	}
	

}
