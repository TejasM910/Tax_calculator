package TAX;

import java.util.Scanner;
public class TAX {
		public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("welcome to tax application");
		System.out.println("please Login to continue--");
		System.out.println("user-");
		String name =sc.nextLine();
		System.out.println("password-");
		String pass=sc.nextLine();
		if(name.equals("admin")&& pass.equals("admin@123")) {
			System.out.println("login Succesfully");
			Homepage.main();
		}
		else {
			System.out.println("password or id error");
		}
		
		
		
	}
		
		}