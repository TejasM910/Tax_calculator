package TAX;

public class VehicleBaseClass {
	private int regno;
	private String brand;
	private int velocity;
	private int seats;
	private String vehicletype;
	private double cost;
	private double tax;
	
	public VehicleBaseClass(int regno, String brand, int velocity, int seats, String vehicletype, double cost,
			double tax) {
		super();
		this.regno = regno;
		this.brand = brand;
		this.velocity = velocity;
		this.seats = seats;
		this.vehicletype = vehicletype;
		this.cost = cost;
		this.tax = tax;
	}
	
	public int getRegno() {
		return regno;
	}

	public void setRegno(int regno) {
		this.regno = regno;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getVelocity() {
		return velocity;
	}

	public void setVelocity(int velocity) {
		this.velocity = velocity;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}

	public String getVehicletype() {
		return vehicletype;
	}

	public void setVehicletype(String vehicletype) {
		this.vehicletype = vehicletype;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	
	
	
	

}
