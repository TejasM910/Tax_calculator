package TAX;

import java.util.HashMap;
import java.util.Scanner;

public class Operationclass {
    static HashMap<Integer, Baseclass> s = new HashMap<Integer, Baseclass>();
    static HashMap<Integer, VehicleBaseClass> v = new HashMap<Integer, VehicleBaseClass>();

    public Operationclass() {
        super();
    }

    // -------------------- PROPERTY SECTION --------------------
    public static void property() {
        if (s.isEmpty()) {
            s.put(101, new Baseclass(101, 1200, 2500.0, 10, 'y', 0.0));
            s.put(102, new Baseclass(102, 800, 1800.0, 5, 'n', 0.0));
            s.put(103, new Baseclass(103, 1500, 3000.0, 8, 'y', 0.0));
        }

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Add property details");
            System.out.println("2. Calculate property tax");
            System.out.println("3. Display all properties");
            System.out.println("4. Back to main menu");

            int options = sc.nextInt();

            if (options == 1) {
                System.out.println("Enter property ID:");
                int id = sc.nextInt();

                System.out.println("Enter the base value of land:");
                double baseprice = sc.nextDouble();

                System.out.println("Enter the built-up area of land:");
                int buildarea = sc.nextInt();

                System.out.println("Enter the age of land in years:");
                int age = sc.nextInt();

                System.out.println("Is the land located in city? (Y:yes, N:no):");
                char incity = sc.next().toLowerCase().charAt(0);

                Baseclass prop = new Baseclass(id, buildarea, baseprice, age, incity, 0.0);
                s.put(id, prop);
                System.out.println(" New Property Added Successfully (ID: " + id + ")");
            }

            else if (options == 2) {
                System.out.println("Enter the property ID to calculate tax:");
                int id = sc.nextInt();

                Baseclass data = s.get(id);
                if (data == null) {
                    System.out.println(" Property ID not found!");
                } else {
                    double result;
                    if (data.getIncity() == 'y') {
                        result = (data.getBuildarea() * data.getAge() * data.getBaseprice()) + (0.5 * data.getBuildarea());
                        System.out.println("Property tax for inside city (ID: " + id + ") = " + result);
                    } else {
                        result = data.getBuildarea() * data.getAge() * data.getBaseprice();
                        System.out.println("Property tax for outside city (ID: " + id + ") = " + result);
                    }
                    data.setPropertytax(result);
                }
            }

            else if (options == 3) {
                if (s.isEmpty()) {
                    System.out.println("No property details found!");
                } else {
                    for (int id : s.keySet()) {
                        Baseclass data = s.get(id);
                        System.out.println("Property ID: " + data.getId() +
                                ", Area: " + data.getBuildarea() +
                                ", Base Price: " + data.getBaseprice() +
                                ", Age: " + data.getAge() +
                                ", In City: " + data.getIncity() +
                                ", Property Tax: " + data.getPropertytax());
                    }
                }
            }

            else if (options == 4) {
                System.out.println("Returning to main menu...");
                break;
            }

            else {
                System.out.println("Invalid option! Try again.");
            }
        }
    }

    // -------------------- VEHICLE SECTION --------------------
    public static void vehicle() {
    	if (v.isEmpty()) {
            v.put(201, new VehicleBaseClass(201, "Maruti Suzuki", 120, 5, "Petrol", 600000.0, 0.0));
            v.put(202, new VehicleBaseClass(202, "Hyundai Creta", 150, 7, "Diesel", 1200000.0, 0.0));
            v.put(203, new VehicleBaseClass(203, "Tata Nexon EV", 160, 5, "Electric", 1500000.0, 0.0));
            v.put(204, new VehicleBaseClass(204, "Hero Splendor", 100, 2, "Petrol", 90000.0, 0.0));
        }
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Add Vehicle Details");
            System.out.println("2. Calculate Vehicle Tax");
            System.out.println("3. Display All Vehicles");
            System.out.println("4. Back to Main Menu");
            int options = sc.nextInt();
            sc.nextLine(); // fix input skip issue

            if (options == 1) {
                System.out.println("Enter Vehicle Registration Number:");
                int regno = sc.nextInt();
                sc.nextLine();

                System.out.println("Enter Brand of the Vehicle:");
                String brand = sc.nextLine();

                System.out.println("Enter Maximum Velocity (KMPH):");
                int velocity = sc.nextInt();

                System.out.println("Enter Seating Capacity:");
                int seats = sc.nextInt();

                System.out.println("Choose Vehicle Type:");
                System.out.println("1. Petrol");
                System.out.println("2. Diesel");
                System.out.println("3. Electric");
                int n = sc.nextInt();
                sc.nextLine();

                String type;
                if (n == 1) {
                    type = "Petrol";
                } else if (n == 2) {
                    type = "Diesel";
                } else if (n == 3) {
                    type = "Electric";
                } else {
                    type = "Unknown";
                }

                System.out.println("Enter Purchase Cost:");
                double cost = sc.nextDouble();

                VehicleBaseClass vb = new VehicleBaseClass(regno, brand, velocity, seats, type, cost, 0.0);
                v.put(regno, vb);
                System.out.println(" Vehicle Record Added Successfully (Reg No: " + regno + ")");
            }

            else if (options == 2) {
                System.out.println("Enter the Registration Number to Calculate Tax:");
                int regno = sc.nextInt();
                VehicleBaseClass d = v.get(regno);
                if (d == null) {
                    System.out.println(" No vehicle found with Registration No: " + regno);
                } else {
                    double result = 0.0;

                    if (d.getVehicletype().equalsIgnoreCase("Petrol")) {
                        result = d.getVelocity() + d.getSeats() + (0.10 * d.getCost());
                        System.out.println("tax updated");
                    } else if (d.getVehicletype().equalsIgnoreCase("Diesel")) {
                        result = d.getVelocity() + d.getSeats() + (0.11 * d.getCost());
                        System.out.println("tax updated");

                    } else if (d.getVehicletype().equalsIgnoreCase("CNG")) {
                        result = d.getVelocity() + d.getSeats() + (0.12 * d.getCost());
                        System.out.println("tax updated");

                    } else {
                        System.out.println(" Unknown vehicle type. Cannot calculate tax!");
                    }

                    d.setTax(result);
                }}
            else if (options == 3) {
                if (v.isEmpty()) {
                    System.out.println("No vehicle details found!");
                } else {
                    for (int regno : v.keySet()) {
                        VehicleBaseClass d = v.get(regno);
                        System.out.println("Reg No: " + d.getRegno() +
                                ", Brand: " + d.getBrand() +
                                ", Velocity: " + d.getVelocity() +
                                ", Seats: " + d.getSeats() +
                                ", Type: " + d.getVehicletype() +
                                ", Cost: " + d.getCost() +
                                ", Tax: " + d.getTax());
                    }
                }
            }

            else if (options == 4) {
                System.out.println("Returning to main menu...");
                break;
            }

            else {
                System.out.println("Invalid option! Try again.");
            }
        }
    }

    public static void total() {
    		System.out.println("-----Total summary------");
    		
    		if(s.isEmpty()&&v.isEmpty()) {
    			System.out.println("no records found");
    			return;
    		}
    		int totaprops=s.size();
    		int totavehic=v.size();
    		 double propTaxSum = s.values().stream().mapToDouble(Baseclass::getPropertytax).sum();
    	        double vehicleTaxSum = v.values().stream().mapToDouble(VehicleBaseClass::getTax).sum();
    	        System.out.println("Total Properties: " + totaprops + " | Total Property Tax: " + propTaxSum);
    	        System.out.println("Total Vehicles: " + totavehic + " | Total Vehicle Tax: " + vehicleTaxSum);
    	        System.out.println(" Grand Total Tax Payable: " + (propTaxSum + vehicleTaxSum));

    		
    		
    		
    	
    	
    }
}
