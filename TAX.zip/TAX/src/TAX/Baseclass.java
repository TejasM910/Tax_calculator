package TAX;

public class Baseclass {
    private int id;
    private int buildarea;
    private double baseprice;
    private int age;
    private char incity;
    private double propertytax;

    public Baseclass(int id, int buildarea, double baseprice, int age, char incity, double propertytax) {
        super();
        this.id = id;
        this.buildarea = buildarea;
        this.baseprice = baseprice;
        this.age = age;
        this.incity = incity;
        this.propertytax = propertytax;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getBuildarea() { return buildarea; }
    public void setBuildarea(int buildarea) { this.buildarea = buildarea; }

    public double getBaseprice() { return baseprice; }
    public void setBaseprice(double baseprice) { this.baseprice = baseprice; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public char getIncity() { return incity; }
    public void setIncity(char incity) { this.incity = incity; }

    public double getPropertytax() { return propertytax; }
    public void setPropertytax(double propertytax) { this.propertytax = propertytax; }
}
