package com.example.pg_app.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pg_app.demo.entity.Tenant;

public interface TenantRepository extends JpaRepository<Tenant, Long> {
}
