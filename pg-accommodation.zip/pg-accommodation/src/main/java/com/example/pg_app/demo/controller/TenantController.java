package com.example.pg_app.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pg_app.demo.entity.Tenant;
import com.example.pg_app.demo.repository.TenantRepository;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/tenant")
public class TenantController {

    @Autowired
    private TenantRepository tenantRepository;

    // Get all tenants
    @GetMapping("/all")
    public List<Tenant> getAllTenants() {
        return tenantRepository.findAll();
    }

    // Get tenant by ID
    @GetMapping("/{id}")
    public ResponseEntity<Tenant> getTenantById(@PathVariable Long id) {
        return tenantRepository.findById(id)
                .map(tenant -> ResponseEntity.ok(tenant))
                .orElse(ResponseEntity.notFound().build());
    }

    // Add a new tenant
    @PostMapping("/add")
    public ResponseEntity<Tenant> addTenant(@Valid @RequestBody Tenant tenant) {
        Tenant savedTenant = tenantRepository.save(tenant);
        return new ResponseEntity<>(savedTenant, HttpStatus.CREATED);
    }

    // Update a tenant
    @PutMapping("/update/{id}")
    public ResponseEntity<Tenant> updateTenant(@PathVariable Long id, @Valid @RequestBody Tenant tenantDetails) {
        return tenantRepository.findById(id).map(tenant -> {
            tenant.setName(tenantDetails.getName());
            tenant.setAge(tenantDetails.getAge());
            tenant.setEmail(tenantDetails.getEmail());
            tenant.setCity(tenantDetails.getCity());
            Tenant updatedTenant = tenantRepository.save(tenant);
            return ResponseEntity.ok(updatedTenant);
        }).orElse(ResponseEntity.notFound().build());
    }

    // Delete a tenant
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteTenant(@PathVariable Long id) {
        if (tenantRepository.existsById(id)) {
            tenantRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}