package com.example.pg_app.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pg_app.demo.entity.Owner;

public interface OwnerRepository extends JpaRepository<Owner, Long> {
}
