package com.example.pg_app.demo.service;

import java.util.List;

import com.example.pg_app.demo.entity.PgPlace;

public interface PgService {
    List<PgPlace> getAvailableByCity(String city);
    List<PgPlace> getAvailableByLocality(String locality);
    PgPlace getPgDetails(Long id);
    PgPlace addPgPlace(PgPlace place);
    PgPlace updateStatus(Long id, Boolean available);
}
