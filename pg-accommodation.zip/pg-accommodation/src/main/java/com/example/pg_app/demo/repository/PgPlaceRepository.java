package com.example.pg_app.demo.repository;



import com.example.pg_app.demo.entity.PgPlace;
import com.example.pg_app.demo.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PgPlaceRepository extends JpaRepository<PgPlace, Long> {
    List<PgPlace> findByCityAndAvailableTrue(String city);
    List<PgPlace> findByLocalityAndAvailableTrue(String locality);
}
